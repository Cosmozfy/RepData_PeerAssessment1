RepData_PeerAssessment1
=======================

For Coursera's Reproducable Research Course, Peer Assignment 1
This assignment was performed using a markdown document (rmd file). 
